
      <div class="row justify-content-center">
          <div class="col col-lg-10 ">
            <form>
              <div class="form-row align-items-center">
                <div class="col-md-3 col-sm-6 my-1">
                  <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Preferência</label>
                  <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                    <option selected>Categoria...</option>
                    <option value="1">Apartamento</option>
                    <option value="2">Casa</option>
                    <option value="3">Fazenda</option>
                    <option value="4">Lote</option>
                    <option value="5">Ponto de Comércio</option>
                    <option value="6">Salas para alugar</option>
                  </select>
                </div>

                <div class="col-md-3 col-sm-6 my-1">
                  <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Preferência</label>
                  <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                    <option selected>Interesse...</option>
                    <option value="1">Venda</option>
                    <option value="2">Locação</option>
                  </select>
                </div>

                <div class="col-md-3 col-sm-6 my-1">
                  <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Preferência</label>
                  <select class="custom-select mr-sm-2" id="inlineFormCustomSelect">
                    <option selected>Região...</option>
                    <option value="1">Janaúba</option>
                    <option value="2">Inserir outras cidades</option>
                  </select>
                </div>

                <div class="col-md-3 col-sm-6 my-1">
                  <button type="submit" class="btn btn-secondary btn-block">Pesquisar</button>
                </div>

               </div>
            </form>
          </div>
      </div>