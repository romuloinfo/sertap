<div class="header">

    <nav class="navbar navbar-expand-md bg-dark navbar-dark text-center fixed-top">
    <!-- <nav class="navbar navbar-expand-md bg-dark navbar-dark text-center"> -->
      <!-- <img class="logo-foto" src="imagens/oie_transparent2.png" /> -->
    <div class="container">
      <span style="color:yellow">IMAGEM LOGO SERTAP</span>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home</a>
          </li>
          <!-- <li class="nav-item">
          <a class="nav-link" href="desenvolvedor.php">Sobre</a>
        </li> -->
          <!-- <li>
            <div class="dropdown">
              <button
                class="btn btn-outline-dark btn-default pt-2"
                type="button"
                data-toggle="dropdown"
                style="border: none;"
              >
                <span class="" style="color: rgb(162, 159, 159);">Produtos <i class="fas fa-angle-down"></i></span>
              </button>

              <ul class="dropdown-menu text-center" style="background: rgb(50, 49, 49); text-decoration: none;">
                <li><a href="adulto.php" style="color: white; text-decoration: none;">Adulto</a></li>
                <li><a href="infantil.php" style="color: white; text-decoration: none;">Infantil</a></li>
                <li><a href="pecas.php" style="color: white; text-decoration: none;">Peças</a></li>
              </ul>
            </div>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" href="#">Empresa</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Locação</a>
          </li>
             <li class="nav-item">
            <a class="nav-link" href="#">Venda</a>
          </li>
             <li class="nav-item">
            <a class="nav-link" href="#">Localização</a>
          </li>
             <li class="nav-item">
            <a class="nav-link" href="#">Fale Conosco</a>
          </li>
        </ul>
      </div>
   </div>
    </nav>
</div>
